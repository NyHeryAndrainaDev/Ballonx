@echo off
REM Lance BalloonX (Windows 10). Double-clic ou : run_windows.bat
if not exist .venv (python -m venv .venv)
call .venv\Scripts\activate
pip install -q -r requirements.txt
flask --app balloonx init-db
python run.py
