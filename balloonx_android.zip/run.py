"""Lance BalloonX sur le réseau local : python run.py   (http://IP_DU_PC:5000)"""
import os
from balloonx import create_app

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("BALLOONX_HOST", "0.0.0.0")   # 0.0.0.0 = accessible aux autres appareils du wifi
    port = int(os.environ.get("BALLOONX_PORT", "5000"))
    try:
        from waitress import serve
        print(f"BalloonX (waitress) sur http://{host}:{port}")
        serve(app, host=host, port=port, threads=8)
    except ImportError:
        print("waitress absent : serveur de développement Flask.")
        app.run(host=host, port=port, threaded=True)
