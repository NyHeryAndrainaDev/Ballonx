"""Vérifications STATIQUES des exigences visuelles (HTML/CSS/JS).
Elles prouvent que le code respecte les consignes ; elles ne remplacent pas un test visuel dans un navigateur."""
import re
import unittest
from pathlib import Path

from tests.helpers import BaseCase

STATIC = Path(__file__).resolve().parent.parent / "balloonx" / "static"
CSS = (STATIC / "style.css").read_text(encoding="utf-8")
JS = (STATIC / "game.js").read_text(encoding="utf-8")


def rule(selector):
    m = re.search(re.escape(selector) + r"\s*\{([^}]*)\}", CSS)
    return m.group(1) if m else ""


class UiRequirements(BaseCase):
    def test_game_page_contains_balloon_man_multiplier_and_green_button(self):
        cl = self.client_for(self.make_user())
        html = cl.get("/game").get_data(as_text=True)
        for needle in ('id="balloon"', 'id="man"', 'id="mult"', 'id="action-btn"', "MISE", 'id="bet-input"', 'id="balance"'):
            self.assertIn(needle, html)
        self.assertIn("background:#000000", rule(".game-area").replace(" ", ""))
        self.assertIn("var(--green)", rule(".btn.green"))
        self.assertIn("var(--yellow)", rule(".btn.yellow"))

    def test_man_shrinks_linearly_with_two_keyframes_only(self):
        self.assertRegex(rule(".man.shrinking"), r"animation:\s*man-shrink\s+var\(--shrink,\s*12s\)\s+linear\s+forwards")
        kf = re.search(r"@keyframes man-shrink\s*\{(.*?\})\s*\}", CSS, re.S).group(1)
        stops = re.findall(r"(from|to|\d+%)\s*\{", kf)
        self.assertEqual(stops, ["from", "to"])             # pas de palier intermédiaire, pas d'accélération
        self.assertNotIn("steps(", CSS)
        self.assertNotIn("ease", rule(".man.shrinking"))
        self.assertIn("scale(1)", kf); self.assertIn("scale(.08)", kf)

    def test_balloon_size_is_never_animated_or_scaled(self):
        for sel in (".balloon", ".balloon.popped", ".balloon-wrap"):
            self.assertNotIn("scale", rule(sel), sel)
        float_kf = re.search(r"@keyframes float\s*\{(.*?)\}\s*\}", CSS, re.S).group(1)
        self.assertNotIn("scale", float_kf); self.assertNotIn("width", float_kf); self.assertNotIn("height", float_kf)
        self.assertIn("translateY", float_kf)
        self.assertNotRegex(JS, r"balloon\.style\.(width|height|transform)")
        self.assertNotRegex(JS, r"balloon\.setAttribute\(\s*['\"](width|height|viewBox)")

    def test_man_vanishing_is_only_visual(self):
        body = re.search(r"function vanish\(\)\s*\{(.*?)\}", JS, re.S).group(1)
        self.assertIn("vanished", body)
        self.assertNotIn("api(", body); self.assertNotIn("fetch", body)
        self.assertIn("visibility:hidden", rule(".man.vanished").replace(" ", ""))

    def test_client_has_no_randomness_and_no_crash_logic(self):
        self.assertNotIn("Math.random", JS)
        self.assertNotIn("crypto.getRandomValues", JS)
        self.assertNotRegex(JS, r"(0\.07|7\s*%|\*\s*1\.0?7|0\.93)")
        # le multiplicateur affiché vient du serveur
        self.assertIn("s.multiplier", JS)

    def test_polling_is_500ms_http(self):
        html = self.client_for(self.make_user()).get("/game").get_data(as_text=True)
        self.assertIn('data-poll="500"', html)
        self.assertNotIn("WebSocket", JS); self.assertNotIn("io(", JS)

    def test_state_exposes_shrink_duration_from_server(self):
        s = self.client_for(self.make_user()).get("/api/state").get_json()
        self.assertEqual(s["shrink_seconds"], 12); self.assertEqual(s["tick_ms"], 500)


if __name__ == "__main__":
    unittest.main()
