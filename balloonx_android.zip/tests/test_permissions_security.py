from werkzeug.security import check_password_hash

from tests.helpers import BaseCase


class Permissions(BaseCase):
    def setUp(self):
        super().setUp()
        self.p = self.make_user("player1", 500)
        self.a = self.make_user("boss", 0, role="admin")
        self.cp, self.ca = self.client_for(self.p), self.client_for(self.a)

    def test_anonymous_is_blocked(self):
        anon = self.app.test_client()
        self.assertEqual(anon.get("/game").status_code, 302)
        self.assertEqual(anon.get("/api/state").status_code, 401)
        self.assertEqual(anon.get("/admin/").status_code, 302)
        with anon.session_transaction() as s:
            s["_csrf"] = "tok"
        self.assertEqual(anon.post("/api/bet", json={"amount": 5}, headers=self.H).status_code, 401)

    def test_player_cannot_reach_admin(self):
        for path in ("/admin/", "/admin/users", f"/admin/users/{self.p}", "/admin/treasury", "/admin/rounds", "/admin/audit"):
            self.assertEqual(self.cp.get(path).status_code, 403, path)
        r = self.cp.post(f"/admin/users/{self.p}/adjust", data={"csrf_token": "tok", "amount": "100000", "reason": "je triche"})
        self.assertEqual(r.status_code, 403)
        r = self.cp.post("/admin/treasury/adjust", data={"csrf_token": "tok", "amount": "100000", "reason": "je triche"})
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.balance(self.p), 500)
        self.assertEqual(self.treasury(), 0)

    def test_admin_can_view_everything(self):
        self.cp.get("/api/state")
        for path in ("/admin/", "/admin/users", f"/admin/users/{self.p}", "/admin/treasury", "/admin/rounds", "/admin/audit"):
            self.assertEqual(self.ca.get(path).status_code, 200, path)

    def test_csrf_is_enforced(self):
        self.cp.get("/api/state")
        self.assertEqual(self.cp.post("/api/bet", json={"amount": 5}).status_code, 400)
        self.assertEqual(self.cp.post("/api/bet", json={"amount": 5}, headers={"X-CSRF-Token": "wrong"}).status_code, 400)
        self.assertEqual(self.ca.post(f"/admin/users/{self.p}/adjust", data={"amount": "5", "reason": "test test"}).status_code, 400)
        self.assertEqual(self.app.test_client().post("/login", data={"username": "a", "password": "b"}).status_code, 400)
        self.assertEqual(self.balance(self.p), 500)

    def test_admin_adjust_requires_reason_and_is_audited(self):
        bad = self.ca.post(f"/admin/users/{self.p}/adjust", data={"csrf_token": "tok", "amount": "100", "reason": ""})
        self.assertEqual(bad.status_code, 302)
        self.assertEqual(self.balance(self.p), 500)
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM audit_log").fetchone()[0], 0)
        ok = self.ca.post(f"/admin/users/{self.p}/adjust", data={"csrf_token": "tok", "amount": "250", "reason": "Bonus de test"})
        self.assertEqual(ok.status_code, 302)
        self.assertEqual(self.balance(self.p), 750)
        c = self.conn()
        a = c.execute("SELECT * FROM audit_log").fetchone()
        self.assertEqual((a["admin_id"], a["action"], a["target_user_id"], a["amount"], a["reason"]),
                         (self.a, "adjust_user_balance", self.p, 250, "Bonus de test"))
        t = c.execute("SELECT * FROM transactions WHERE type='admin_adjust'").fetchone()
        self.assertEqual((t["amount"], t["admin_id"], t["balance_after"]), (250, self.a, 750))

    def test_admin_cannot_make_balance_negative(self):
        self.ca.post(f"/admin/users/{self.p}/adjust", data={"csrf_token": "tok", "amount": "-501", "reason": "Trop fort"})
        self.assertEqual(self.balance(self.p), 500)
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM audit_log").fetchone()[0], 0)

    def test_treasury_adjust_is_separate_and_audited(self):
        self.ca.post("/admin/treasury/adjust", data={"csrf_token": "tok", "amount": "5000", "reason": "Dotation initiale"})
        self.assertEqual(self.treasury(), 5000)
        c = self.conn()
        row = c.execute("SELECT * FROM treasury_ledger").fetchone()
        self.assertEqual((row["type"], row["delta"], row["admin_id"], row["reason"]), ("admin_adjust", 5000, self.a, "Dotation initiale"))
        self.assertEqual(c.execute("SELECT action FROM audit_log").fetchone()[0], "adjust_treasury")
        self.assertEqual(self.balance(self.p), 500)           # soldes joueurs intacts
        self.ca.post("/admin/treasury/adjust", data={"csrf_token": "tok", "amount": "100", "reason": "x"})
        self.assertEqual(self.treasury(), 5000)               # justification trop courte -> refusé

    def test_xss_in_audit_reason_is_escaped(self):
        self.ca.post("/admin/treasury/adjust", data={"csrf_token": "tok", "amount": "1", "reason": "<script>alert(1)</script>"})
        html = self.ca.get("/admin/audit").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", html)

    def test_security_headers(self):
        r = self.cp.get("/game")
        self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        self.assertNotIn("<script>", r.get_data(as_text=True).replace('<script src', ''))   # aucun script inline


class AuthTests(BaseCase):
    def reg(self, cl, name, pw="password123"):
        with cl.session_transaction() as s:
            s["_csrf"] = "tok"
        return cl.post("/register", data={"csrf_token": "tok", "username": name, "password": pw})

    def test_register_hashes_password_and_gives_fictive_bonus(self):
        cl = self.app.test_client()
        self.assertEqual(self.reg(cl, "newbie").status_code, 302)
        c = self.conn()
        u = c.execute("SELECT * FROM users WHERE username='newbie'").fetchone()
        self.assertEqual((u["role"], u["balance"]), ("player", 1000))
        self.assertNotEqual(u["password_hash"], "password123")
        self.assertTrue(check_password_hash(u["password_hash"], "password123"))
        self.assertEqual(c.execute("SELECT type FROM transactions").fetchone()[0], "signup_bonus")

    def test_register_validation(self):
        cl = self.app.test_client()
        self.assertEqual(self.reg(cl, "x").status_code, 200)
        self.assertEqual(self.reg(cl, "<script>").status_code, 200)
        self.assertEqual(self.reg(cl, "okname", "short").status_code, 200)
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM users").fetchone()[0], 0)
        self.reg(cl, "Dupe")
        self.assertEqual(self.reg(self.app.test_client(), "dupe").status_code, 409)   # insensible à la casse

    def test_no_default_admin_exists(self):
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0], 0)

    def test_create_admin_cli(self):
        runner = self.app.test_cli_runner()
        short = runner.invoke(args=["create-admin", "--username", "boss", "--password", "court"])
        self.assertNotEqual(short.exit_code, 0)
        ok = runner.invoke(args=["create-admin", "--username", "boss", "--password", "un-mot-de-passe-long"])
        self.assertEqual(ok.exit_code, 0, ok.output)
        c = self.conn()
        u = c.execute("SELECT * FROM users WHERE username='boss'").fetchone()
        self.assertEqual(u["role"], "admin")
        self.assertNotIn("un-mot-de-passe-long", u["password_hash"])
        self.assertEqual(c.execute("SELECT action FROM audit_log").fetchone()[0], "create_admin")

    def test_login_and_rate_limit(self):
        self.make_user("alice", 10)
        cl = self.app.test_client()
        with cl.session_transaction() as s:
            s["_csrf"] = "tok"
        good = cl.post("/login", data={"csrf_token": "tok", "username": "alice", "password": "password123"})
        self.assertEqual(good.status_code, 302)
        cl2 = self.app.test_client()
        with cl2.session_transaction() as s:
            s["_csrf"] = "tok"
        codes = [cl2.post("/login", data={"csrf_token": "tok", "username": "alice", "password": "bad"}).status_code for _ in range(10)]
        self.assertEqual(codes[:8], [401] * 8)
        self.assertEqual(codes[8:], [429, 429])
        blocked = cl2.post("/login", data={"csrf_token": "tok", "username": "alice", "password": "password123"})
        self.assertEqual(blocked.status_code, 429)

    def test_inactive_user_is_logged_out(self):
        uid = self.make_user("ghost", 10)
        cl = self.client_for(uid)
        self.assertEqual(cl.get("/api/state").status_code, 200)
        c = self.conn(); c.execute("UPDATE users SET is_active=0 WHERE id=?", (uid,)); c.close()
        self.assertEqual(cl.get("/api/state").status_code, 401)
