import os
import tempfile
import unittest

from balloonx import create_app
from balloonx.db import connect


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t

    def advance(self, dt):
        self.t += dt


class Script:
    """Tirages de crash scriptés : True = crash. Compte le nombre de tirages consommés."""
    def __init__(self, seq=()):
        self.seq, self.calls = list(seq), 0

    def __call__(self):
        self.calls += 1
        return self.seq.pop(0) if self.seq else False


class BaseCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "t.sqlite3")
        self.clock = Clock()
        self.draw = Script()
        self.app = create_app({
            "TESTING": True, "SECRET_KEY": "test", "DATABASE": self.db_path, "JOURNAL_MODE": "DELETE",
            "CLOCK": self.clock, "CRASH_DRAW": self.draw, "BETTING_SECONDS": 8, "RESULT_SECONDS": 5,
        })
        self.cfg = self.app.config

    def conn(self):
        return connect(self.db_path, "DELETE")

    def make_user(self, name="alice", balance=1000, role="player", password="password123"):
        from werkzeug.security import generate_password_hash
        c = self.conn()
        cur = c.execute(
            "INSERT INTO users (username, password_hash, role, balance, created_at) VALUES (?,?,?,?,?)",
            (name, generate_password_hash(password), role, balance, 0))
        c.close()
        return cur.lastrowid

    def client_for(self, uid):
        cl = self.app.test_client()
        with cl.session_transaction() as s:
            s["uid"], s["_csrf"] = uid, "tok"
        return cl

    H = {"X-CSRF-Token": "tok"}

    def state(self, cl):
        return cl.get("/api/state").get_json()

    def to_flight(self):
        """Ouvre une partie puis avance jusqu'au début du vol."""
        return self.clock.advance(0)

    def balance(self, uid):
        c = self.conn(); b = c.execute("SELECT balance FROM users WHERE id=?", (uid,)).fetchone()[0]; c.close(); return b

    def treasury(self):
        c = self.conn(); b = c.execute("SELECT balance FROM treasury WHERE id=1").fetchone()[0]; c.close(); return b
