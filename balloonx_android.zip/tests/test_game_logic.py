import unittest

from balloonx import game
from tests.helpers import BaseCase, Script


class MathTests(unittest.TestCase):
    def test_multiplier_is_linear_1_plus_0_7_t(self):
        for k in range(0, 200):
            t = 0.5 * k
            self.assertEqual(game.multiplier_x100(k), round((1 + 0.7 * t) * 100))
        self.assertEqual(game.fmt_mult(game.multiplier_x100(0)), "1.00")
        self.assertEqual(game.fmt_mult(game.multiplier_x100(1)), "1.35")   # +0,35 par 500 ms
        self.assertEqual(game.fmt_mult(game.multiplier_x100(2)), "1.70")

    def test_constant_step_no_acceleration(self):
        steps = {game.multiplier_x100(k + 1) - game.multiplier_x100(k) for k in range(500)}
        self.assertEqual(steps, {35})

    def test_potential_gross_and_net(self):
        self.assertEqual(game.potential_gross(100, 0), 100)
        self.assertEqual(game.potential_gross(100, 4), 240)
        self.assertEqual(game.potential_gross(10, 1), 13)   # 13,5 arrondi à l'inférieur
        self.assertEqual(game.potential_gross(100, 4) - 100, 140)

    def test_parse_amount_rejects_bad_values(self):
        for bad in (0, -1, "0", "-5", "abc", "", 1.5, True, None, [], {}, 10 ** 10, "1e3", "١٢"):
            with self.assertRaises(game.GameError, msg=repr(bad)):
                game.parse_amount(bad, 1, 1_000_000)
        self.assertEqual(game.parse_amount("25", 1, 100), 25)
        self.assertEqual(game.parse_amount(25, 1, 100), 25)

    def test_crash_probability_is_7_percent(self):
        n = 200_000
        crashes = sum(game.default_draw(700) for _ in range(n))
        rate = crashes / n
        self.assertTrue(0.065 < rate < 0.075, rate)       # ~6 écarts-types de marge
        self.assertTrue(0.925 < 1 - rate < 0.935)


class EngineTests(BaseCase):
    def start_flight(self, cl):
        self.state(cl)                      # crée la partie (mises ouvertes)
        self.clock.advance(8.0)             # fin des mises -> début du vol
        return self.state(cl)

    def test_one_independent_draw_per_500ms(self):
        cl = self.client_for(self.make_user())
        s = self.start_flight(cl)
        self.assertEqual((s["phase"], s["multiplier"]), ("flying", "1.00"))
        self.assertEqual(self.draw.calls, 0)
        self.clock.advance(0.49); self.state(cl); self.assertEqual(self.draw.calls, 0)
        self.clock.advance(0.01); s = self.state(cl); self.assertEqual(self.draw.calls, 1)
        self.assertEqual(s["multiplier"], "1.35")
        self.clock.advance(1.0); s = self.state(cl); self.assertEqual(self.draw.calls, 3)
        self.assertEqual(s["multiplier"], "2.05")

    def test_polling_twice_does_not_redraw(self):
        cl = self.client_for(self.make_user())
        self.start_flight(cl)
        self.clock.advance(1.0)
        self.state(cl); n = self.draw.calls
        for _ in range(5):
            self.state(cl)
        self.assertEqual(self.draw.calls, n)

    def test_server_script_decides_crash(self):
        cl = self.client_for(self.make_user())
        self.draw.seq = [False, False, True]
        self.start_flight(cl)
        self.clock.advance(2.0)             # plus de vérifications (4) que nécessaire (3)
        s = self.state(cl)
        self.assertEqual(s["phase"], "crashed")
        self.assertEqual(s["crash_multiplier"], "1.70")     # dernier palier survécu
        self.assertEqual(self.draw.calls, 3)                # aucun tirage après le crash
        c = self.conn()
        r = c.execute("SELECT * FROM rounds").fetchone()
        self.assertEqual((r["survived_ticks"], r["crash_check"]), (2, 3))

    def test_flight_multiplier_never_depends_on_client(self):
        cl = self.client_for(self.make_user())
        self.start_flight(cl)
        self.clock.advance(2.0)
        a = cl.get("/api/state?multiplier=99&crash=1&t=1000").get_json()
        self.assertEqual(a["multiplier"], "2.40")
        self.assertEqual(a["phase"], "flying")

    def test_new_round_after_result_delay(self):
        cl = self.client_for(self.make_user())
        self.draw.seq = [True]
        self.start_flight(cl)
        self.clock.advance(0.5); s = self.state(cl)
        self.assertEqual(s["phase"], "crashed"); first = s["round_id"]
        self.clock.advance(4.0); self.assertEqual(self.state(cl)["phase"], "crashed")
        self.clock.advance(1.5); s = self.state(cl)
        self.assertEqual((s["phase"], s["round_id"]), ("betting", first + 1))

    def test_idle_server_does_not_create_thousands_of_rounds(self):
        cl = self.client_for(self.make_user())
        self.state(cl)
        self.clock.advance(3 * 3600)
        self.draw.seq = []                   # survie par défaut : le vol continue
        self.draw.calls = 0
        s = self.state(cl)
        c = self.conn()
        self.assertLessEqual(c.execute("SELECT COUNT(*) FROM rounds").fetchone()[0], 3)


if __name__ == "__main__":
    unittest.main()
