import threading

from tests.helpers import BaseCase


class BetFlow(BaseCase):
    def setUp(self):
        super().setUp()
        self.uid = self.make_user("alice", 1000)
        self.cl = self.client_for(self.uid)
        self.state(self.cl)                  # partie ouverte

    def bet(self, amount, cl=None, **extra):
        return (cl or self.cl).post("/api/bet", json={"amount": amount, **extra}, headers=self.H)

    def cash(self, cl=None):
        return (cl or self.cl).post("/api/cashout", json={}, headers=self.H)

    def fly(self, seconds=0.0):
        self.clock.advance(8.0 + seconds)

    # ---------------- mises
    def test_bet_debits_exactly_once_and_rejects_repeat(self):
        r = self.bet(100); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.balance(self.uid), 900)
        r2 = self.bet(100); self.assertEqual((r2.status_code, r2.get_json()["error"]), (409, "already_bet"))
        self.assertEqual(self.balance(self.uid), 900)
        c = self.conn()
        self.assertEqual(c.execute("SELECT COUNT(*) FROM bets").fetchone()[0], 1)
        self.assertEqual(c.execute("SELECT COUNT(*) FROM transactions WHERE type='bet'").fetchone()[0], 1)

    def test_invalid_bets_are_refused_without_touching_balance(self):
        for bad in (0, -10, "abc", 1.5, True, None, 10 ** 10, 1001):
            r = self.bet(bad)
            self.assertIn(r.status_code, (400, 409), bad)
            self.assertEqual(self.balance(self.uid), 1000, bad)
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM bets").fetchone()[0], 0)

    def test_bet_refused_once_flight_started(self):
        self.fly(0.0)
        r = self.bet(50); self.assertEqual((r.status_code, r.get_json()["error"]), (409, "not_betting"))
        self.assertEqual(self.balance(self.uid), 1000)

    def test_client_cannot_inject_balance_or_user(self):
        other = self.make_user("bob", 1000)
        self.bet(10, user_id=other, balance=10 ** 9, multiplier=50)
        self.assertEqual(self.balance(other), 1000)
        self.assertEqual(self.balance(self.uid), 990)

    # ---------------- retraits
    def test_cashout_pays_server_computed_amount_once(self):
        self.bet(100)
        self.fly(2.0)                        # 4 vérifications survécues -> 2,40×
        s = self.state(self.cl)
        self.assertEqual(s["me"]["bet"]["potential_gross"], 240)
        self.assertEqual(s["me"]["bet"]["potential_net"], 140)
        r = self.cash(); j = r.get_json()
        self.assertEqual((r.status_code, j["payout"], j["net"], j["multiplier"]), (200, 240, 140, "2.40"))
        self.assertEqual(self.balance(self.uid), 900 + 240)
        r2 = self.cash(); self.assertEqual((r2.status_code, r2.get_json()["error"]), (409, "already_resolved"))
        self.assertEqual(self.balance(self.uid), 1140)
        # caisse : seul le bénéfice net est versé (la mise était en séquestre)
        self.assertEqual(self.treasury(), -140)
        row = self.conn().execute("SELECT * FROM treasury_ledger").fetchone()
        self.assertEqual((row["type"], row["gross_amount"], row["stake_amount"]), ("payout", 240, 100))

    def test_potential_amount_updates_every_500ms(self):
        self.bet(100); self.fly(0.0)
        seen = []
        for _ in range(4):
            seen.append(self.state(self.cl)["me"]["bet"]["potential_gross"])
            self.clock.advance(0.5)
        self.assertEqual(seen, [100, 135, 170, 205])

    def test_cashout_requires_bet_and_flight(self):
        self.assertEqual(self.cash().get_json()["error"], "not_flying")   # pendant les mises
        self.fly(1.0)
        self.assertEqual(self.cash().get_json()["error"], "no_bet")

    def test_cashout_after_crash_is_refused_and_crash_is_not_undone(self):
        self.bet(100)
        self.draw.seq = [False, True]        # crash à la 2e vérification
        self.fly(1.0)
        r = self.cash()
        self.assertEqual((r.status_code, r.get_json()["error"]), (409, "not_flying"))
        calls = self.draw.calls
        for _ in range(3):
            s = self.state(self.cl)
            self.assertEqual((s["phase"], s["crash_multiplier"]), ("crashed", "1.35"))
        self.assertEqual(self.draw.calls, calls)              # pas de nouveau tirage : décision définitive
        self.assertEqual(self.balance(self.uid), 900)
        self.assertEqual(self.treasury(), 100)                # mise perdue -> caisse
        self.assertEqual(s["me"]["bet"]["status"], "lost")

    def test_cashout_just_before_crash_check_still_works(self):
        self.bet(100)
        self.draw.seq = [True]
        self.fly(0.49)                       # la 1re vérification (0,5 s) n'a pas encore eu lieu
        r = self.cash(); self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["payout"], 100)         # 1,00×

    def test_conservation_of_fictive_credits(self):
        bob = self.make_user("bob", 1000); cb = self.client_for(bob)
        def total():
            c = self.conn()
            u = c.execute("SELECT COALESCE(SUM(balance),0) FROM users").fetchone()[0]
            e = c.execute("SELECT COALESCE(SUM(amount),0) FROM bets WHERE status='active'").fetchone()[0]
            return u + e + self.treasury()
        start = total()
        self.bet(300); self.bet(200, cb)
        self.assertEqual(total(), start)
        self.draw.seq = [False] * 3 + [True]
        self.fly(1.5); self.assertEqual(self.cash(cb).status_code, 200)
        self.assertEqual(total(), start)
        self.clock.advance(5); self.state(self.cl)
        self.assertEqual(total(), start)
        self.assertEqual(self.balance(self.uid), 700)         # alice a perdu 300
        self.assertEqual(self.balance(bob), 800 + 200 * 205 // 100)

    # ---------------- concurrence
    def test_concurrent_cashouts_pay_only_once(self):
        self.bet(100); self.fly(2.0)
        results = []
        def worker():
            cl = self.client_for(self.uid)
            results.append(cl.post("/api/cashout", json={}, headers=self.H).status_code)
        ts = [threading.Thread(target=worker) for _ in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(results).count(200), 1)
        self.assertEqual(self.balance(self.uid), 900 + 240)
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM transactions WHERE type='payout'").fetchone()[0], 1)

    def test_concurrent_bets_only_one_accepted(self):
        results = []
        def worker():
            cl = self.client_for(self.uid)
            results.append(cl.post("/api/bet", json={"amount": 100}, headers=self.H).status_code)
        ts = [threading.Thread(target=worker) for _ in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(results).count(200), 1)
        self.assertEqual(self.balance(self.uid), 900)

    def test_concurrent_first_requests_create_a_single_round(self):
        fresh = self.make_user("carol", 10)
        def worker():
            self.client_for(fresh).get("/api/state")
        ts = [threading.Thread(target=worker) for _ in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(self.conn().execute("SELECT COUNT(*) FROM rounds").fetchone()[0], 1)
