"""Point d'entrée Python de l'APK (appelé depuis Kotlin via Chaquopy).

Mode hôte : démarre le serveur BalloonX (Flask + SQLite) sur 0.0.0.0:PORT dans un thread de fond.
Les autres téléphones du même Wi-Fi s'y connectent avec http://IP_DE_L_HOTE:PORT.

Fonctions appelées par Kotlin :
    start(data_dir, port=5000) -> "" si OK, sinon un message d'erreur lisible
    stop()                     -> arrête le serveur
    is_running()               -> bool
    last_error()               -> dernier message d'erreur ("" si aucun)
"""
import os
import socket
import threading
import time
import traceback

_lock = threading.Lock()
_state = {"server": None, "thread": None, "port": None, "error": ""}


class _Server:
    """Petit adaptateur : waitress en production (dans l'APK), werkzeug en secours (tests sur PC)."""

    def __init__(self, app, host, port):
        self._kind = "waitress"
        try:
            from waitress import create_server
            self._srv = create_server(app, host=host, port=port, threads=8,
                                      ident="BalloonX", clear_untrusted_proxy_headers=True)
        except ImportError:
            from werkzeug.serving import make_server
            self._kind = "werkzeug"
            self._srv = make_server(host, port, app, threaded=True)

    def run(self):
        if self._kind == "waitress":
            self._srv.run()
        else:
            self._srv.serve_forever()

    def close(self):
        if self._kind == "waitress":
            self._srv.close()
        else:
            self._srv.shutdown()
            self._srv.server_close()


def _wait_until_listening(port, timeout=10.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.15)
    return False


def start(data_dir, port=5000):
    """Démarre le serveur (sans effet s'il tourne déjà). Ne lève jamais : renvoie "" ou le message d'erreur."""
    port = int(port)
    with _lock:
        if _state["server"] is not None:
            return ""
        _state["error"] = ""
        try:
            os.makedirs(data_dir, exist_ok=True)
            os.environ["BALLOONX_INSTANCE_DIR"] = str(data_dir)   # base SQLite + clé secrète dans le dossier privé de l'app
            os.environ["BALLOONX_SETUP"] = "1"                    # écran de création de l'admin (visible seulement sur l'hôte)
            from balloonx import create_app
            app = create_app()
            server = _Server(app, "0.0.0.0", port)
        except (OSError, SystemExit) as exc:                       # SystemExit : werkzeug quitte si le port est pris
            _state["error"] = f"Port {port} indisponible ({exc}). Ferme l'autre partie ou change de port."
            return _state["error"]
        except Exception as exc:                                   # noqa: BLE001 - on remonte un texte simple à l'interface
            _state["error"] = f"Démarrage impossible : {exc}\n{traceback.format_exc(limit=3)}"
            return _state["error"]

        def _run():
            try:
                server.run()
            except Exception as exc:                               # noqa: BLE001
                _state["error"] = f"Le serveur s'est arrêté : {exc}"
            finally:
                with _lock:
                    if _state["server"] is server:
                        _state["server"] = None
                        _state["thread"] = None

        thread = threading.Thread(target=_run, name="balloonx-server", daemon=True)
        _state.update(server=server, thread=thread, port=port)
        thread.start()

    if not _wait_until_listening(port):
        stop()
        _state["error"] = "Le serveur n'a pas répondu à temps."
        return _state["error"]
    return ""


def stop():
    with _lock:
        server, thread = _state["server"], _state["thread"]
        _state.update(server=None, thread=None)
    if server is not None:
        try:
            server.close()
        except Exception:                                          # noqa: BLE001
            pass
    if thread is not None:
        thread.join(timeout=5)


def is_running():
    return _state["server"] is not None


def last_error():
    return _state["error"]
