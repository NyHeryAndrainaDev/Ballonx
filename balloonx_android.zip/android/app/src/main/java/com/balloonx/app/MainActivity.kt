package com.balloonx.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.balloonx.app.HostService.State

private val BG = Color.parseColor("#0B0B12")
private val GREEN = Color.parseColor("#16A34A")
private val BLUE = Color.parseColor("#2563EB")
private val RED = Color.parseColor("#DC2626")
private val GREY = Color.parseColor("#374151")
private val MUTED = Color.parseColor("#9CA3AF")
private val OK_TXT = Color.parseColor("#86EFAC")
private val WARN_TXT = Color.parseColor("#FDE68A")
private val ERR_TXT = Color.parseColor("#FCA5A5")
private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Écran unique : Accueil → (Créer une partie = hôte) ou (Rejoindre = saisir l'adresse de l'hôte) → jeu dans une WebView.
 * Toute l'interface est construite en code (pas de fichiers XML de mise en page).
 */
class MainActivity : Activity() {

    private enum class Screen { HOME, HOST, JOIN, GAME }

    companion object {
        private const val REQ_NOTIF = 100
    }

    private var current = Screen.HOME
    private var gameOrigin = Screen.HOME
    private var webView: WebView? = null
    private var startRequested = false   // l'utilisateur vient de demander le démarrage (le service n'a pas encore répondu)
    private var stopping = false         // l'utilisateur vient de demander l'arrêt (le service n'a pas encore répondu)

    private val prefs by lazy { getSharedPreferences("balloonx", MODE_PRIVATE) }

    // ------------------------------------------------------------------ cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = HostService.state
        if (st == State.STARTING || st == State.RUNNING) showHost() else showHome()
    }

    override fun onResume() {
        super.onResume()
        HostService.listener = { onServiceChanged() }
        webView?.onResume()
        if (current == Screen.HOST) showHost()
    }

    override fun onPause() {
        HostService.listener = null
        webView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        destroyWebView()
        unbindNetwork()
        super.onDestroy()          // le serveur hôte, lui, continue de tourner (service au premier plan)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)  // appui sur la notification
        if (current != Screen.GAME && HostService.state != State.STOPPED) showHost()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when (current) {
            Screen.GAME -> {
                val wv = webView
                if (wv != null && wv.canGoBack()) wv.goBack() else closeGame()
            }
            Screen.HOST, Screen.JOIN -> showHome()
            Screen.HOME -> super.onBackPressed()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) beginHosting()   // même si refusé : le service fonctionne, sans notification visible
    }

    private fun onServiceChanged() {
        if (HostService.state != State.STOPPED) startRequested = false
        if (HostService.state == State.STOPPED) stopping = false
        if (current == Screen.HOST || current == Screen.HOME) {
            if (current == Screen.HOST) showHost() else showHome()
        }
    }

    // ------------------------------------------------------------------ écrans

    private fun showHome() {
        current = Screen.HOME
        destroyWebView()
        unbindNetwork()
        val st = HostService.state
        val hosting = !stopping && (startRequested || st == State.STARTING || st == State.RUNNING)
        setContentView(page {
            addLabel("BalloonX", 32f, bold = true)
            addLabel("Jeu Crash à crédits fictifs : sans internet, en multijoueur sur le même Wi-Fi.", 15f, MUTED)
            if (hosting) {
                addButton("Reprendre ma partie hébergée") { showHost() }
            } else {
                addButton("Créer une partie (je suis l'hôte)") { startHostingFlow() }
            }
            addButton("Rejoindre une partie", BLUE) { showJoin() }
            addLabel(
                "Hôte : ce téléphone fait tourner le jeu. Joueurs : ils se connectent avec l'adresse que l'hôte leur donne.",
                13f, MUTED
            )
        })
    }

    private fun showHost() {
        current = Screen.HOST
        destroyWebView()
        val raw = HostService.state
        val st = if (raw == State.STOPPED && startRequested) State.STARTING else raw
        val ips = if (st == State.RUNNING) HostService.hostAddresses() else emptyList()
        setContentView(page {
            addLabel("Partie hébergée", 24f, bold = true)
            when (st) {
                State.STARTING -> addLabel("Démarrage du serveur…", 16f, WARN_TXT)
                State.RUNNING -> {
                    addLabel("Serveur actif ✅", 16f, OK_TXT)
                    if (ips.isEmpty()) {
                        addLabel(
                            "Aucune adresse Wi-Fi détectée. Active le Wi-Fi ou le partage de connexion (point d'accès) de ce téléphone, puis touche « Actualiser ».",
                            14f, WARN_TXT
                        )
                    } else {
                        addLabel("Les autres joueurs (même Wi-Fi) ouvrent :", 14f, MUTED)
                        ips.forEach { ip ->
                            addLabel("http://$ip:${HostService.PORT}", 18f, Color.WHITE, bold = true).setTextIsSelectable(true)
                        }
                        addLabel("Ils peuvent aussi installer l'APK et choisir « Rejoindre ».", 13f, MUTED)
                    }
                }
                State.ERROR -> addLabel(HostService.lastError.ifEmpty { "Erreur inconnue." }, 14f, ERR_TXT)
                State.STOPPED -> addLabel("Serveur arrêté.", 16f, MUTED)
            }

            addButton("Jouer sur ce téléphone", enabled = st == State.RUNNING) {
                showGame("http://127.0.0.1:${HostService.PORT}/", Screen.HOST)
            }
            if (st == State.RUNNING) {
                addButton("Partager l'adresse", BLUE, enabled = ips.isNotEmpty()) { shareAddresses(ips) }
                addButton("Actualiser les adresses", GREY) { showHost() }
            }
            if (st == State.ERROR) {
                addButton("Réessayer") { beginHosting() }
            }
            if (st == State.STARTING || st == State.RUNNING) {
                addButton("Arrêter la partie", RED) { stopHosting() }
            }
            addButton("Menu principal", GREY) { showHome() }
        })
    }

    private fun showJoin() {
        current = Screen.JOIN
        destroyWebView()
        setContentView(page {
            addLabel("Rejoindre une partie", 24f, bold = true)
            addLabel(
                "Entre l'adresse affichée sur le téléphone de l'hôte (écran « Partie hébergée »). Vous devez être sur le même Wi-Fi.",
                14f, MUTED
            )
            val input = EditText(context).apply {
                hint = "ex. 192.168.43.1"
                setText(prefs.getString("last_ip", ""))
                setTextColor(Color.WHITE)
                setHintTextColor(MUTED)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                setSingleLine(true)
            }
            addView(input, LinearLayout.LayoutParams(MATCH, WRAP))
            addButton("Se connecter") { connect(input.text.toString()) }
            addButton("Retour", GREY) { showHome() }
        })
    }

    private fun showGame(url: String, origin: Screen) {
        destroyWebView()
        current = Screen.GAME
        gameOrigin = origin
        val allowedHost = Uri.parse(url).host ?: ""

        val wv = WebView(this)
        @Suppress("SetJavaScriptEnabled")
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.settings.setSupportZoom(false)
        wv.setBackgroundColor(Color.BLACK)

        val errorBox = buildErrorBox(url)
        errorBox.visibility = View.GONE

        wv.webViewClient = object : WebViewClient() {
            // On reste sur la même machine : tout lien vers un autre hôte est ignoré.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                request?.url?.host != allowedHost

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                errorBox.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) errorBox.visibility = View.VISIBLE
            }
        }

        webView = wv
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(errorBox, FrameLayout.LayoutParams(MATCH, MATCH))
        })
        wv.loadUrl(url)
    }

    private fun buildErrorBox(url: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(BG)
            setPadding(dp(24), dp(24), dp(24), dp(24))
            isClickable = true   // empêche les touches de traverser vers la WebView
        }
        box.addLabel("Impossible de joindre la partie.", 20f, bold = true)
        box.addLabel(
            "Vérifie que tu es sur le même Wi-Fi que l'hôte, que l'adresse est correcte et que la partie est lancée.",
            14f, MUTED
        )
        box.addButton("Réessayer") {
            box.visibility = View.GONE
            webView?.loadUrl(url)
        }
        box.addButton("Retour", GREY) { closeGame() }
        return box
    }

    // ------------------------------------------------------------------ actions

    private fun startHostingFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        } else {
            beginHosting()
        }
    }

    private fun beginHosting() {
        stopping = false
        startRequested = true
        HostService.start(this)
        showHost()
    }

    private fun stopHosting() {
        startRequested = false
        stopping = true
        HostService.stop(this)
        showHome()
    }

    private fun connect(raw: String) {
        var addr = raw.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
        if (!Regex("^[A-Za-z0-9.\\-]+(:[0-9]{1,5})?$").matches(addr)) {
            Toast.makeText(this, "Adresse invalide (exemple : 192.168.43.1)", Toast.LENGTH_LONG).show()
            return
        }
        if (!addr.contains(":")) addr += ":${HostService.PORT}"
        prefs.edit().putString("last_ip", addr.substringBefore(":")).apply()
        bindToWifi()
        showGame("http://$addr/", Screen.JOIN)
    }

    private fun closeGame() {
        destroyWebView()
        if (gameOrigin == Screen.HOST) showHost() else showJoin()
    }

    private fun shareAddresses(ips: List<String>) {
        val text = "Rejoins ma partie BalloonX (même Wi-Fi) : " +
            ips.joinToString(" ou ") { "http://$it:${HostService.PORT}" }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, "Partager l'adresse"))
    }

    private fun destroyWebView() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        webView?.let {
            it.stopLoading()
            (it.parent as? ViewGroup)?.removeView(it)
            it.destroy()
        }
        webView = null
    }

    // ------------------------------------------------------------------ réseau

    /**
     * Wi-Fi sans internet : Android peut envoyer le trafic de l'app vers les données mobiles et rater l'hôte.
     * On force donc l'app (mode « Rejoindre ») à utiliser le réseau Wi-Fi.
     */
    @Suppress("DEPRECATION")
    private fun bindToWifi() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val wifi = cm.allNetworks.firstOrNull { n ->
                cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
            if (wifi != null) cm.bindProcessToNetwork(wifi)
        } catch (e: Exception) {
            // on continue avec le réseau par défaut
        }
    }

    private fun unbindNetwork() {
        try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).bindProcessToNetwork(null)
        } catch (e: Exception) {
            // rien à défaire
        }
    }

    // ------------------------------------------------------------------ petits outils d'interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun page(content: LinearLayout.() -> Unit): View {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            content()
        }
        return ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(column, ViewGroup.LayoutParams(MATCH, WRAP))
        }
    }

    private fun LinearLayout.addLabel(
        text: String,
        size: Float = 16f,
        color: Int = Color.WHITE,
        bold: Boolean = false
    ): TextView {
        val tv = TextView(context).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        return tv
    }

    private fun LinearLayout.addButton(
        label: String,
        color: Int = GREEN,
        enabled: Boolean = true,
        onClick: () -> Unit
    ): Button {
        val b = Button(context).apply {
            text = label
            setAllCaps(false)
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(if (enabled) color else GREY)
                cornerRadius = dp(12).toFloat()
            }
            minHeight = dp(52)
            minimumHeight = dp(52)
            isEnabled = enabled
            setOnClickListener { onClick() }
        }
        addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        return b
    }
}
