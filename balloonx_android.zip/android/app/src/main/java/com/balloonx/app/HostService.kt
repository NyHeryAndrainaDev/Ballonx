package com.balloonx.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import com.chaquo.python.Python
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Service au premier plan qui héberge la partie : il lance le serveur BalloonX (Python) et le garde
 * en vie quand l'écran s'éteint. L'interface (MainActivity) lit l'état via [state] et [lastError].
 */
class HostService : Service() {

    enum class State { STOPPED, STARTING, RUNNING, ERROR }

    companion object {
        const val ACTION_START = "com.balloonx.app.START"
        const val ACTION_STOP = "com.balloonx.app.STOP"
        const val PORT = 5000

        private const val CHANNEL_ID = "balloonx_host"
        private const val NOTIFICATION_ID = 1

        @Volatile
        var state: State = State.STOPPED
            private set

        @Volatile
        var lastError: String = ""
            private set

        /** Appelé sur le thread principal à chaque changement d'état (l'activité s'y abonne). */
        @Volatile
        var listener: (() -> Unit)? = null

        private val mainHandler = Handler(Looper.getMainLooper())

        private fun update(newState: State, error: String = "") {
            state = newState
            lastError = error
            mainHandler.post { listener?.invoke() }
        }

        fun start(context: Context) {
            val intent = Intent(context, HostService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, HostService::class.java).setAction(ACTION_STOP))
        }

        /**
         * Adresses IPv4 de ce téléphone sur le réseau local (Wi-Fi ou point d'accès), les plus probables d'abord.
         * C'est ce que les autres joueurs tapent : http://ADRESSE:5000
         */
        fun hostAddresses(): List<String> {
            val found = mutableListOf<Pair<Int, String>>()
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces() ?: return emptyList()
                for (nif in interfaces) {
                    if (!nif.isUp || nif.isLoopback) continue
                    val name = nif.name.lowercase()
                    val cellular = listOf("rmnet", "ccmni", "pdp", "tun", "dummy", "v4-", "clat")
                    if (cellular.any { name.startsWith(it) }) continue
                    val rank = if (listOf("wlan", "ap", "swlan", "eth").any { name.startsWith(it) }) 0 else 1
                    for (addr in nif.inetAddresses) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                            val ip = addr.hostAddress ?: continue
                            found.add(rank to ip)
                        }
                    }
                }
            } catch (e: Exception) {
                return emptyList()
            }
            return found.sortedBy { it.first }.map { it.second }.distinct()
        }
    }

    @Volatile
    private var destroyed = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        // Android exige d'appeler startForeground rapidement après startForegroundService.
        try {
            goForeground("Démarrage du serveur…")
        } catch (e: Exception) {
            update(State.ERROR, "Android a refusé le service au premier plan : ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        if (state != State.STARTING && state != State.RUNNING) {
            acquireLocks()
            startServer()
        }
        return START_STICKY   // si Android tue le service, il le relance (intent nul = démarrage)
    }

    override fun onDestroy() {
        destroyed = true
        try {
            Python.getInstance().getModule("balloonx_host").callAttr("stop")
        } catch (e: Throwable) {
            // le serveur n'était peut-être pas démarré : rien à arrêter
        }
        releaseLocks()
        if (state != State.ERROR) update(State.STOPPED)
        super.onDestroy()
    }

    private fun startServer() {
        update(State.STARTING)
        Thread({
            val error = try {
                val dataDir = File(filesDir, "balloonx_data").absolutePath
                Python.getInstance().getModule("balloonx_host")
                    .callAttr("start", dataDir, PORT)
                    .toString()
            } catch (e: Throwable) {
                "Erreur Python : ${e.message}"
            }
            if (destroyed) return@Thread   // le service a été arrêté pendant le démarrage
            if (error.isEmpty()) {
                update(State.RUNNING)
                val ips = hostAddresses()
                val text = if (ips.isEmpty()) "Wi-Fi non détecté (port $PORT)"
                else ips.joinToString("  •  ") { "http://$it:$PORT" }
                getSystemService(NotificationManager::class.java)
                    ?.notify(NOTIFICATION_ID, buildNotification(text))
            } else {
                update(State.ERROR, error)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }, "balloonx-starter").start()
    }

    private fun goForeground(text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Partie hébergée", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, HostService::class.java).setAction(ACTION_STOP),
            flags
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BalloonX — partie hébergée")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Arrêter", stop)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "balloonx:host").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "balloonx:wifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocks() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // déjà libérés
        }
        wakeLock = null
        wifiLock = null
    }
}
