"""Point d'entrée WSGI (PythonAnywhere : pointer le fichier WSGI vers `from wsgi import application`)."""
from balloonx import create_app

application = create_app()
