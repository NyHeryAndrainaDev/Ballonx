# BalloonX — jeu Crash à crédits FICTIFS

Aucun argent réel : pas d'achat, de retrait, d'échange ni de transfert entre joueurs.
Stack : Python + Flask, SQLite, HTML/CSS/JS vanilla, polling HTTP (500 ms), sans WebSocket.

## Arborescence
```
balloonx/
├── balloonx/
│   ├── __init__.py      fabrique d'app, CSRF, en-têtes de sécurité, commandes CLI
│   ├── game.py          MOTEUR : tirages 7 %, multiplicateur, mises, retraits, crash, caisse
│   ├── db.py            SQLite (transactions BEGIN IMMEDIATE)
│   ├── schema.sql       tables
│   ├── auth.py          inscription / connexion / décorateurs
│   ├── play.py          page de jeu + API JSON (/api/state, /api/bet, /api/cashout)
│   ├── admin.py         comptes, ajustements justifiés, caisse, parties, audit
│   ├── templates/       pages Jinja (échappement automatique)
│   └── static/          style.css, game.js, common.js, vendor/ (lucide.min.js facultatif)
├── tests/               46 tests (unittest)
├── run.py               lancement LAN (waitress si installé, sinon Flask)
├── wsgi.py              entrée WSGI (PythonAnywhere)
├── run_windows.bat      installation + lancement en un double-clic
├── requirements.txt
└── instance/            base SQLite + clé secrète (créés automatiquement, hors zip)
```

## Installation (Windows 10, PowerShell ou cmd, dans le dossier du projet)
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
flask --app balloonx init-db
flask --app balloonx create-admin
```
`create-admin` demande le nom et le mot de passe (saisie masquée, 12 caractères minimum).
Aucun mot de passe par défaut n'existe dans le code.

## Lancer
```
python run.py
```
- Sur le PC : http://127.0.0.1:5000
- Sur les téléphones du même wifi : http://IP_DU_PC:5000 (trouve l'IP avec `ipconfig`).
- Si Windows demande d'autoriser Python dans le pare-feu, accepte pour les réseaux privés.
- Compte admin : connecte-toi avec ses identifiants, tu arrives sur /admin. Les joueurs s'inscrivent sur /register (1 000 crédits fictifs offerts).

## Tests
```
python -m unittest discover -s tests -v
```
(pytest fonctionne aussi s'il est installé.) Couvre : probabilités 7 %, multiplicateur 1 + 0,7·t, mises, retraits,
double retrait / double mise concurrents, crash, soldes, caisse, conservation des crédits, permissions, CSRF,
XSS, audit, et les exigences visuelles (vérifications statiques du HTML/CSS/JS).

## Règles implémentées
- Partie commune : mises ouvertes 8 s → vol → crash → résultat 5 s → nouvelle partie (réglable dans `create_app`).
- Pendant le vol, une vérification indépendante toutes les 500 ms : 7 % crash / 93 % survie (`secrets`).
  Les tirages sont faits côté serveur, de façon paresseuse à chaque requête (aucun thread), dans une transaction
  `BEGIN IMMEDIATE` ; chaque résultat est enregistré et définitif.
- Multiplicateur M(t) = 1 + 0,7·t : 1,00× puis +0,35× par palier de 500 ms. Le montant brut = mise × M (arrondi à
  l'entier inférieur) ; il est mis à jour à chaque vérification de 500 ms, et le retrait est payé au palier validé par le serveur.
- Mise débitée une seule fois (UNIQUE partie+joueur). Retrait : `UPDATE ... WHERE status='active'` => un seul paiement possible.
- Crash avant retrait : mise perdue → caisse centrale. Retrait : la caisse verse le bénéfice net (la mise est « en séquestre »).
  Contrôle : soldes joueurs + mises actives + caisse = constante (hors ajustements admin), testé.
- Admin : ajustements de soldes et de caisse avec justification obligatoire (5 car. min.), journal d'audit, ledger de caisse.

## Interface
- Zone de jeu `#000000`. Ballon rouge à taille fixe (seule sa position flotte, jamais son échelle).
- Petit homme séparé, visible dès l'ouverture des mises, qui rétrécit en continu au lancement du vol :
  animation CSS à deux images-clés avec `linear` (vitesse constante), durée `SHRINK_SECONDS` (12 s). À la taille minimale
  il disparaît visuellement. C'est uniquement visuel : aucun appel serveur, aucun effet sur le crash.
- Bouton vert « MISE » → bouton jaune « RETIRER <montant brut> » pendant le vol.

## Icônes Lucide
Copie `lucide.min.js` dans `balloonx/static/vendor/`. S'il est absent, l'application fonctionne sans icônes.

## PythonAnywhere (plan gratuit) plus tard
1. Envoie le projet, crée un virtualenv, `pip install Flask` (waitress inutile).
2. Fichier WSGI : `import sys; sys.path.insert(0, '/home/TON_NOM/balloonx'); from wsgi import application`.
3. Variables : `BALLOONX_JOURNAL=DELETE` si WAL pose problème, `BALLOONX_COOKIE_SECURE=1` (HTTPS).
4. Console : `flask --app balloonx init-db` puis `flask --app balloonx create-admin`.
Aucun thread ni WebSocket : le moteur avance à chaque requête de polling, donc compatible avec le plan gratuit.

## Intégration future à MadaPlay
Tout le moteur est dans `game.py` (fonctions pures sur une connexion SQLite, sans dépendance à Flask) :
`place_bet`, `cash_out`, `public_state`, `treasury_add`, `user_credit`. Pour intégrer, remplacer `user_credit`
par le wallet MadaPlay et brancher `play.py` comme plugin de jeu.

## Limites connues
- Rien n'a été testé dans un vrai navigateur dans cet environnement : l'animation visuelle est vérifiée par le code
  (tests statiques), pas par un rendu. Teste sur ton téléphone et dis-moi ce qui doit être ajusté.
- Le limiteur de tentatives de connexion est basé sur la base SQLite (pas de proxy inverse géré).
- Serveur unique SQLite : adapté à un LAN / petit groupe, pas à une forte charge.
