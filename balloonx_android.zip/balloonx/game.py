"""Moteur de jeu BalloonX — le SERVEUR est l'unique autorité.

Principes
- Pas de thread d'arrière-plan : l'état est avancé « paresseusement » à chaque requête
  (compatible PythonAnywhere gratuit). Tout avancement se fait dans une transaction
  BEGIN IMMEDIATE, donc un seul processus décide à la fois.
- À chaque vérification (toutes les 0,5 s depuis le début du vol) : un tirage indépendant,
  7 % crash / 93 % survie. Chaque tirage est persisté (survived_ticks / crash_check).
- Multiplicateur : M(t) = 1 + 0,7·t, soit +0,35× toutes les 500 ms. Calcul en entiers (×100).
- Montants en crédits FICTIFS entiers. Brut = mise × M, arrondi à l'entier inférieur.
"""
import secrets

TICK_SECONDS = 0.5
BASE_X100 = 100
STEP_X100 = 35          # 0,35× par vérification de 500 ms (= 0,7 × 0,5 s)


class GameError(Exception):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


# ----------------------------------------------------------------- mathématiques
def multiplier_x100(ticks):
    """Multiplicateur ×100 après `ticks` vérifications survécues (M = 1 + 0,7·t, t = 0,5·ticks)."""
    return BASE_X100 + STEP_X100 * ticks


def fmt_mult(x100):
    return f"{x100 / 100:.2f}"


def potential_gross(amount, ticks):
    return amount * multiplier_x100(ticks) // 100


def parse_amount(value, minimum=1, maximum=10 ** 9):
    """Entier strictement positif uniquement (refuse bool, float, texte non numérique)."""
    if isinstance(value, bool):
        raise GameError("bad_amount", "Montant invalide.")
    if isinstance(value, int):
        amount = value
    elif isinstance(value, str) and value.strip().isascii() and value.strip().isdigit() and len(value.strip()) <= 12:
        amount = int(value.strip())
    else:
        raise GameError("bad_amount", "Montant invalide : entier positif requis.")
    if amount < minimum:
        raise GameError("bad_amount", f"La mise minimale est de {minimum}.")
    if amount > maximum:
        raise GameError("bad_amount", f"La mise maximale est de {maximum}.")
    return amount


def default_draw(per_10000=700):
    """Un tirage de crash : True = crash (7 % par défaut), via `secrets` (CSPRNG)."""
    return secrets.randbelow(10000) < per_10000


# ----------------------------------------------------------------- caisse / ledger
def treasury_add(conn, kind, delta, now, **kw):
    conn.execute("UPDATE treasury SET balance = balance + ? WHERE id = 1", (delta,))
    bal = conn.execute("SELECT balance FROM treasury WHERE id = 1").fetchone()["balance"]
    conn.execute(
        """INSERT INTO treasury_ledger
           (type, delta, balance_after, gross_amount, stake_amount, round_id, bet_id,
            user_id, admin_id, reason, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (kind, delta, bal, kw.get("gross"), kw.get("stake"), kw.get("round_id"),
         kw.get("bet_id"), kw.get("user_id"), kw.get("admin_id"), kw.get("reason"), now),
    )
    return bal


def user_credit(conn, user_id, delta, kind, now, **kw):
    """Modifie le solde d'un joueur (le CHECK balance >= 0 protège contre le négatif)."""
    cur = conn.execute(
        "UPDATE users SET balance = balance + ? WHERE id = ? AND balance + ? >= 0",
        (delta, user_id, delta),
    )
    if cur.rowcount != 1:
        raise GameError("insufficient", "Solde insuffisant.")
    bal = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()["balance"]
    conn.execute(
        """INSERT INTO transactions
           (user_id, type, amount, balance_after, round_id, bet_id, admin_id, note, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (user_id, kind, delta, bal, kw.get("round_id"), kw.get("bet_id"),
         kw.get("admin_id"), kw.get("note"), now),
    )
    return bal


# ----------------------------------------------------------------- avancement des parties
def _latest(conn):
    return conn.execute("SELECT * FROM rounds ORDER BY id DESC LIMIT 1").fetchone()


def _needs_change(r, now, cfg):
    if r is None:
        return True
    if r["status"] == "betting":
        return now >= r["betting_ends_at"]
    if r["status"] == "flying":
        return int((now - r["flight_start"]) // TICK_SECONDS) > r["survived_ticks"]
    return now >= r["crashed_at"] + cfg["RESULT_SECONDS"]


def _new_round(conn, now, scheduled, betting):
    # Si on est dans les temps, on garde le calendrier ; sinon (serveur inactif) on repart de now.
    start = scheduled if (scheduled is not None and now - scheduled < betting) else now
    ends = start + betting
    conn.execute(
        "INSERT INTO rounds (status, created_at, betting_ends_at, flight_start) VALUES ('betting',?,?,?)",
        (start, ends, ends),
    )


def _settle_crash(conn, round_id, now):
    for b in conn.execute(
        "SELECT id, user_id, amount FROM bets WHERE round_id = ? AND status = 'active'", (round_id,)
    ).fetchall():
        cur = conn.execute(
            "UPDATE bets SET status='lost', resolved_at=? WHERE id=? AND status='active'", (now, b["id"])
        )
        if cur.rowcount == 1:  # mise perdue -> caisse centrale fictive, une seule fois
            treasury_add(conn, "lost_bet", b["amount"], now, stake=b["amount"],
                         round_id=round_id, bet_id=b["id"], user_id=b["user_id"])


def advance_locked(conn, now, cfg, draw=None):
    """Avance la machine d'états. À appeler dans une transaction IMMEDIATE déjà ouverte."""
    draw = draw or (lambda: default_draw(cfg["CRASH_PER_10000"]))
    betting = cfg["BETTING_SECONDS"]
    for _ in range(10000):  # garde-fou
        r = _latest(conn)
        if r is None:
            _new_round(conn, now, None, betting)
            continue
        if r["status"] == "crashed":
            due = r["crashed_at"] + cfg["RESULT_SECONDS"]
            if now >= due:
                _new_round(conn, now, due, betting)
                continue
            return r
        if r["status"] == "betting":
            if now >= r["betting_ends_at"]:
                conn.execute("UPDATE rounds SET status='flying' WHERE id=?", (r["id"],))
                continue
            return r
        # vol en cours : une vérification indépendante par tranche de 500 ms écoulée
        target = int((now - r["flight_start"]) // TICK_SECONDS)
        survived = r["survived_ticks"]
        crashed_at_check = None
        while survived < target:
            k = survived + 1
            if draw():
                crashed_at_check = k
                break
            survived = k
        if crashed_at_check is not None:
            crash_time = r["flight_start"] + crashed_at_check * TICK_SECONDS
            conn.execute(
                "UPDATE rounds SET status='crashed', survived_ticks=?, crash_check=?, crashed_at=? WHERE id=?",
                (survived, crashed_at_check, crash_time, r["id"]),
            )
            _settle_crash(conn, r["id"], crash_time)
            continue
        if survived != r["survived_ticks"]:
            conn.execute("UPDATE rounds SET survived_ticks=? WHERE id=?", (survived, r["id"]))
        return _latest(conn)
    raise RuntimeError("advance_locked: boucle anormale")


def advance(conn, now, cfg, draw=None):
    """Avance l'état si nécessaire (transaction propre, validée immédiatement)."""
    from .db import immediate
    r = _latest(conn)
    if not _needs_change(r, now, cfg):
        return r
    with immediate(conn):
        return advance_locked(conn, now, cfg, draw)


# ----------------------------------------------------------------- actions joueur
def place_bet(conn, user_id, amount, now, cfg, draw=None):
    amount = parse_amount(amount, cfg["MIN_BET"], cfg["MAX_BET"])
    err, result = None, None
    from .db import immediate
    with immediate(conn):
        r = advance_locked(conn, now, cfg, draw)   # validé même si on refuse la mise (pas de rollback)
        if r["status"] != "betting" or now >= r["betting_ends_at"]:
            err = GameError("not_betting", "Les mises sont fermées pour cette partie.", 409)
        else:
            u = conn.execute("SELECT balance, is_active FROM users WHERE id=?", (user_id,)).fetchone()
            if u is None or not u["is_active"]:
                err = GameError("forbidden", "Compte indisponible.", 403)
            elif u["balance"] < amount:
                err = GameError("insufficient", "Solde insuffisant.", 409)
            else:
                try:
                    conn.execute("SAVEPOINT bet")
                    cur = conn.execute(
                        "INSERT INTO bets (round_id, user_id, amount, created_at) VALUES (?,?,?,?)",
                        (r["id"], user_id, amount, now),
                    )
                    bet_id = cur.lastrowid
                    bal = user_credit(conn, user_id, -amount, "bet", now, round_id=r["id"], bet_id=bet_id)
                    conn.execute("RELEASE bet")
                    result = {"bet_id": bet_id, "balance": bal, "amount": amount, "round_id": r["id"]}
                except Exception as exc:  # doublon (UNIQUE) ou solde
                    conn.execute("ROLLBACK TO bet")
                    conn.execute("RELEASE bet")
                    import sqlite3
                    if isinstance(exc, sqlite3.IntegrityError):
                        err = GameError("already_bet", "Tu as déjà misé sur cette partie.", 409)
                    elif isinstance(exc, GameError):
                        err = exc
                    else:
                        raise
    if err:
        raise err
    return result


def cash_out(conn, user_id, now, cfg, draw=None):
    err, result = None, None
    from .db import immediate
    with immediate(conn):
        r = advance_locked(conn, now, cfg, draw)
        if r["status"] != "flying":
            err = GameError("not_flying", "Le retrait n'est possible que pendant le vol.", 409)
        else:
            b = conn.execute(
                "SELECT * FROM bets WHERE round_id=? AND user_id=?", (r["id"], user_id)
            ).fetchone()
            if b is None:
                err = GameError("no_bet", "Aucune mise sur cette partie.", 409)
            elif b["status"] != "active":
                err = GameError("already_resolved", "Cette mise est déjà réglée.", 409)
            else:
                ticks = r["survived_ticks"]
                m100 = multiplier_x100(ticks)
                gross = potential_gross(b["amount"], ticks)
                cur = conn.execute(
                    """UPDATE bets SET status='cashed', cash_ticks=?, cash_mult_x100=?, payout=?, resolved_at=?
                       WHERE id=? AND status='active'""",
                    (ticks, m100, gross, now, b["id"]),
                )
                if cur.rowcount != 1:       # garde anti double retrait
                    err = GameError("already_resolved", "Cette mise est déjà réglée.", 409)
                else:
                    bal = user_credit(conn, user_id, gross, "payout", now, round_id=r["id"], bet_id=b["id"])
                    # La mise était déjà « en séquestre » : la caisse ne verse que le bénéfice net.
                    treasury_add(conn, "payout", -(gross - b["amount"]), now, gross=gross,
                                 stake=b["amount"], round_id=r["id"], bet_id=b["id"], user_id=user_id)
                    result = {"balance": bal, "payout": gross, "net": gross - b["amount"],
                              "multiplier": fmt_mult(m100), "round_id": r["id"]}
    if err:
        raise err
    return result


# ----------------------------------------------------------------- état public (polling)
def public_state(conn, user, now, cfg, draw=None):
    r = advance(conn, now, cfg, draw)
    st = {"server_time": now, "round_id": r["id"], "phase": r["status"],
          "shrink_seconds": cfg["SHRINK_SECONDS"], "tick_ms": int(TICK_SECONDS * 1000)}
    ticks = r["survived_ticks"]
    m100 = multiplier_x100(ticks)
    st["multiplier"] = fmt_mult(m100)
    if r["status"] == "betting":
        st["betting_remaining"] = max(0.0, round(r["betting_ends_at"] - now, 3))
        st["multiplier"] = fmt_mult(BASE_X100)
    elif r["status"] == "flying":
        st["flight_elapsed"] = max(0.0, round(now - r["flight_start"], 3))
    else:
        st["flight_elapsed"] = round(r["crashed_at"] - r["flight_start"], 3)
        st["crash_multiplier"] = fmt_mult(m100)
        st["next_round_in"] = max(0.0, round(r["crashed_at"] + cfg["RESULT_SECONDS"] - now, 3))
    row = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS total FROM bets WHERE round_id=?", (r["id"],)
    ).fetchone()
    st["bets_count"], st["bets_total"] = row["n"], row["total"]
    hist = conn.execute(
        "SELECT survived_ticks FROM rounds WHERE status='crashed' ORDER BY id DESC LIMIT 12"
    ).fetchall()
    st["history"] = [fmt_mult(multiplier_x100(h["survived_ticks"])) for h in hist]
    if user is not None:
        bal = conn.execute("SELECT balance FROM users WHERE id=?", (user["id"],)).fetchone()["balance"]
        me = {"balance": bal, "bet": None}
        b = conn.execute("SELECT * FROM bets WHERE round_id=? AND user_id=?", (r["id"], user["id"])).fetchone()
        if b is not None:
            info = {"amount": b["amount"], "status": b["status"]}
            if b["status"] == "active" and r["status"] == "flying":
                g = potential_gross(b["amount"], ticks)
                info.update(potential_gross=g, potential_net=g - b["amount"])
            elif b["status"] == "cashed":
                info.update(payout=b["payout"], net=b["payout"] - b["amount"],
                            multiplier=fmt_mult(b["cash_mult_x100"]))
            me["bet"] = info
        st["me"] = me
    return st
