"""BalloonX — jeu Crash à crédits FICTIFS (aucun argent réel)."""
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime
from pathlib import Path

import click
from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash

from . import db as dbmod

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
ROOT = Path(__file__).resolve().parent.parent


def _load_secret(instance_path):
    env = os.environ.get("BALLOONX_SECRET_KEY")
    if env:
        return env
    f = Path(instance_path) / "secret_key"
    if f.exists():
        return f.read_text().strip()
    key = secrets.token_hex(32)
    f.write_text(key)
    try:
        os.chmod(f, 0o600)
    except OSError:
        pass
    return key


def _insert_admin(conn, username, password, now, source, only_if_none=False):
    """Crée le compte admin + une ligne d'audit, dans une seule transaction.

    only_if_none=True : refuse (ValueError) si un admin existe déjà (vérifié dans la transaction,
    donc sûr même si deux requêtes arrivent en même temps).
    """
    with dbmod.immediate(conn):
        if only_if_none and conn.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone():
            raise ValueError("admin_exists")
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, role, balance, created_at) VALUES (?,?, 'admin', 0, ?)",
            (username, generate_password_hash(password), now))
        conn.execute(
            "INSERT INTO audit_log (admin_id, action, target_user_id, amount, reason, ip, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (cur.lastrowid, "create_admin", cur.lastrowid, None,
             "Création via la ligne de commande" if source == "cli" else "Création au premier lancement (téléphone hôte)",
             source, now))


def create_app(test_config=None):
    # BALLOONX_INSTANCE_DIR : dossier inscriptible pour la base et la clé secrète (Android : dossier privé de l'app).
    instance_dir = os.environ.get("BALLOONX_INSTANCE_DIR") or str(ROOT / "instance")
    app = Flask(__name__, instance_path=instance_dir, instance_relative_config=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    app.config.update(
        DATABASE=os.environ.get("BALLOONX_DB", str(Path(app.instance_path) / "balloonx.sqlite3")),
        JOURNAL_MODE=os.environ.get("BALLOONX_JOURNAL", "WAL"),   # "DELETE" si WAL pose souci
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("BALLOONX_COOKIE_SECURE", "0") == "1",  # 1 en HTTPS
        PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 7,
        MAX_CONTENT_LENGTH=16 * 1024,
        ALLOW_REGISTER=os.environ.get("BALLOONX_ALLOW_REGISTER", "1") == "1",
        # Écran de création de l'admin au premier lancement (mode hôte Android). Désactivé par défaut.
        SETUP_ENABLED=os.environ.get("BALLOONX_SETUP", "0") == "1",
        # --- règles du jeu (fictif) ---
        CRASH_PER_10000=700,        # 7 % de crash à chaque vérification de 500 ms
        BETTING_SECONDS=8,
        RESULT_SECONDS=5,
        SHRINK_SECONDS=12,          # durée du rétrécissement du petit homme (animation uniquement)
        INITIAL_BALANCE=1000,
        MIN_BET=1,
        MAX_BET=1_000_000,
        LOGIN_MAX_ATTEMPTS=8,
        LOGIN_WINDOW_SECONDS=600,
        CLOCK=time.time,            # injectable pour les tests
        CRASH_DRAW=None,            # injectable pour les tests (sinon secrets)
    )
    if test_config:
        app.config.update(test_config)
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = _load_secret(app.instance_path)

    with app.app_context():
        conn = dbmod.connect(app.config["DATABASE"], app.config["JOURNAL_MODE"])
        dbmod.init_schema(conn)
        conn.close()
    app.teardown_appcontext(dbmod.close_db)

    app.jinja_env.globals["has_lucide"] = (Path(app.static_folder) / "vendor" / "lucide.min.js").exists()

    @app.template_filter("dt")
    def _dt(ts):
        return datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M:%S") if ts else "—"

    @app.template_filter("num")
    def _num(n):
        return f"{n:,}".replace(",", " ") if n is not None else "—"

    # ------------------------------------------------------------ CSRF + utilisateur courant
    def csrf_token():
        if "_csrf" not in session:
            session["_csrf"] = secrets.token_urlsafe(32)
        return session["_csrf"]

    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.before_request
    def _load_user_and_csrf():
        g.user = None
        uid = session.get("uid")
        if uid:
            u = dbmod.get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            if u is None or not u["is_active"]:
                session.clear()
            else:
                g.user = u
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token", "")
            expected = session.get("_csrf", "")
            if not expected or not secrets.compare_digest(str(sent), expected):
                if request.path.startswith("/api/"):
                    return jsonify(error="csrf", message="Jeton CSRF invalide."), 400
                abort(400, "Jeton CSRF invalide.")

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'self'")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    from . import auth, admin, play
    app.register_blueprint(auth.bp)
    app.register_blueprint(play.bp)
    app.register_blueprint(admin.bp)

    def _setup_open():
        """L'écran /setup n'existe que : si activé, depuis l'appareil lui-même (127.0.0.1), et tant qu'aucun admin n'existe."""
        if not app.config["SETUP_ENABLED"] or request.remote_addr not in ("127.0.0.1", "::1"):
            return False
        return dbmod.get_db().execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone() is None

    @app.route("/")
    def index():
        if _setup_open():
            return redirect(url_for("setup"))
        return redirect(url_for("play.game") if g.user else url_for("auth.login"))

    @app.route("/setup", methods=["GET", "POST"])
    def setup():
        if not _setup_open():
            abort(404)
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            confirm = request.form.get("confirm", "")
            if not USERNAME_RE.match(username):
                flash("Nom invalide : 3 à 20 caractères (lettres, chiffres, _).", "error")
            elif len(password) < 12 or len(password) > 128:
                flash("Mot de passe : 12 à 128 caractères pour l'admin.", "error")
            elif password != confirm:
                flash("Les deux mots de passe ne correspondent pas.", "error")
            else:
                try:
                    _insert_admin(dbmod.get_db(), username, password, app.config["CLOCK"](), "setup", only_if_none=True)
                except ValueError:
                    abort(404)
                except sqlite3.IntegrityError:
                    flash("Ce nom d'utilisateur est déjà pris.", "error")
                    return render_template("setup.html"), 409
                flash("Administrateur créé. Connecte-toi.", "ok")
                return redirect(url_for("auth.login"))
        return render_template("setup.html")

    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(400)
    def _err(e):
        if request.path.startswith("/api/"):
            return jsonify(error="http", message=getattr(e, "description", "Erreur")), e.code
        from flask import render_template
        return render_template("error.html", code=e.code, message=getattr(e, "description", "")), e.code

    # ------------------------------------------------------------ commandes CLI
    @app.cli.command("init-db")
    def init_db_cmd():
        """Crée / met à jour les tables (sans rien effacer)."""
        conn = dbmod.connect(app.config["DATABASE"], app.config["JOURNAL_MODE"])
        dbmod.init_schema(conn)
        conn.close()
        click.echo(f"Base prête : {app.config['DATABASE']}")

    @app.cli.command("create-admin")
    @click.option("--username", prompt="Nom d'utilisateur admin")
    @click.password_option("--password", prompt="Mot de passe (12 caractères min.)",
                           confirmation_prompt=True, hide_input=True)
    def create_admin_cmd(username, password):
        """Crée le compte administrateur (mot de passe saisi de façon masquée, jamais stocké en clair)."""
        if not USERNAME_RE.match(username):
            raise click.ClickException("Nom invalide : 3 à 20 caractères (lettres, chiffres, _).")
        if len(password) < 12:
            raise click.ClickException("Mot de passe trop court (12 caractères minimum pour un admin).")
        conn = dbmod.connect(app.config["DATABASE"], app.config["JOURNAL_MODE"])
        dbmod.init_schema(conn)
        try:
            _insert_admin(conn, username, password, app.config["CLOCK"](), "cli")
        except Exception as exc:
            conn.close()
            raise click.ClickException(f"Impossible de créer l'admin : {exc}")
        conn.close()
        click.echo(f"Administrateur « {username} » créé.")

    return app
