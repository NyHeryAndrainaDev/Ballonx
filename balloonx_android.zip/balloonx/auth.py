"""Inscription, connexion, déconnexion, décorateurs d'autorisation."""
import functools

from flask import Blueprint, current_app, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import USERNAME_RE
from .db import get_db, immediate
from .game import user_credit

bp = Blueprint("auth", __name__)
_DUMMY_HASH = generate_password_hash("dummy-password-for-timing")


def login_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            if request.path.startswith("/api/"):
                return jsonify(error="auth", message="Connexion requise."), 401
            return redirect(url_for("auth.login"))
        return view(*a, **kw)
    return wrapped


def admin_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            return redirect(url_for("auth.login"))
        if g.user["role"] != "admin":
            from flask import abort
            abort(403, "Accès réservé à l'administrateur.")
        return view(*a, **kw)
    return wrapped


def _ip():
    return request.remote_addr or "?"


@bp.route("/register", methods=["GET", "POST"])
def register():
    if not current_app.config["ALLOW_REGISTER"]:
        flash("Les inscriptions sont fermées.", "error")
        return redirect(url_for("auth.login"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not USERNAME_RE.match(username):
            flash("Nom invalide : 3 à 20 caractères (lettres, chiffres, _).", "error")
        elif len(password) < 8 or len(password) > 128:
            flash("Mot de passe : 8 à 128 caractères.", "error")
        else:
            conn, now = get_db(), current_app.config["CLOCK"]()
            try:
                with immediate(conn):
                    cur = conn.execute(
                        "INSERT INTO users (username, password_hash, role, balance, created_at) VALUES (?,?, 'player', 0, ?)",
                        (username, generate_password_hash(password), now))
                    user_credit(conn, cur.lastrowid, current_app.config["INITIAL_BALANCE"], "signup_bonus",
                                now, note="Crédits fictifs de bienvenue")
                    uid = cur.lastrowid
            except Exception as exc:
                import sqlite3
                if isinstance(exc, sqlite3.IntegrityError):
                    flash("Ce nom d'utilisateur est déjà pris.", "error")
                    return render_template("register.html"), 409
                raise
            session.clear()
            session["uid"] = uid
            session.permanent = True
            return redirect(url_for("play.game"))
    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()[:40]
        password = request.form.get("password", "")[:200]
        conn, now, cfg = get_db(), current_app.config["CLOCK"](), current_app.config
        since = now - cfg["LOGIN_WINDOW_SECONDS"]
        n = conn.execute(
            "SELECT COUNT(*) AS n FROM login_attempts WHERE created_at > ? AND (ip = ? OR username = ? COLLATE NOCASE)",
            (since, _ip(), username)).fetchone()["n"]
        if n >= cfg["LOGIN_MAX_ATTEMPTS"]:
            flash("Trop de tentatives. Réessaie dans quelques minutes.", "error")
            return render_template("login.html"), 429
        u = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        ok = check_password_hash(u["password_hash"] if u else _DUMMY_HASH, password)
        if u is None or not ok or not u["is_active"]:
            conn.execute("INSERT INTO login_attempts (username, ip, created_at) VALUES (?,?,?)", (username, _ip(), now))
            flash("Identifiants incorrects.", "error")
            return render_template("login.html"), 401
        conn.execute("DELETE FROM login_attempts WHERE username = ? COLLATE NOCASE", (username,))
        session.clear()                 # anti fixation de session
        session["uid"] = u["id"]
        session.permanent = True
        return redirect(url_for("admin.dashboard") if u["role"] == "admin" else url_for("play.game"))
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
