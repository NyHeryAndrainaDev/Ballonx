-- BalloonX : schéma SQLite (crédits fictifs uniquement, montants en entiers)
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT    NOT NULL,
    role          TEXT    NOT NULL DEFAULT 'player' CHECK (role IN ('player','admin')),
    balance       INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS rounds (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    status          TEXT    NOT NULL CHECK (status IN ('betting','flying','crashed')),
    created_at      REAL    NOT NULL,
    betting_ends_at REAL    NOT NULL,
    flight_start    REAL    NOT NULL,
    survived_ticks  INTEGER NOT NULL DEFAULT 0,
    crash_check     INTEGER,            -- numéro de la vérification (1,2,3...) qui a fait crasher
    crashed_at      REAL
);

CREATE TABLE IF NOT EXISTS bets (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    round_id       INTEGER NOT NULL REFERENCES rounds(id),
    user_id        INTEGER NOT NULL REFERENCES users(id),
    amount         INTEGER NOT NULL CHECK (amount > 0),
    status         TEXT    NOT NULL DEFAULT 'active' CHECK (status IN ('active','cashed','lost')),
    cash_ticks     INTEGER,
    cash_mult_x100 INTEGER,
    payout         INTEGER,
    created_at     REAL    NOT NULL,
    resolved_at    REAL,
    UNIQUE (round_id, user_id)          -- une seule mise par joueur et par partie
);

CREATE TABLE IF NOT EXISTS transactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id),
    type          TEXT    NOT NULL CHECK (type IN ('signup_bonus','bet','payout','admin_adjust')),
    amount        INTEGER NOT NULL,       -- variation signée du solde du joueur
    balance_after INTEGER NOT NULL,
    round_id      INTEGER,
    bet_id        INTEGER,
    admin_id      INTEGER,
    note          TEXT,
    created_at    REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS treasury (
    id      INTEGER PRIMARY KEY CHECK (id = 1),
    balance INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS treasury_ledger (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    type          TEXT    NOT NULL CHECK (type IN ('lost_bet','payout','admin_adjust')),
    delta         INTEGER NOT NULL,       -- variation signée de la caisse
    balance_after INTEGER NOT NULL,
    gross_amount  INTEGER,                -- paiement brut versé au joueur (retrait)
    stake_amount  INTEGER,                -- mise initiale concernée
    round_id      INTEGER,
    bet_id        INTEGER,
    user_id       INTEGER,
    admin_id      INTEGER,
    reason        TEXT,
    created_at    REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id       INTEGER REFERENCES users(id),
    action         TEXT    NOT NULL,
    target_user_id INTEGER,
    amount         INTEGER,
    reason         TEXT    NOT NULL,
    ip             TEXT,
    created_at     REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    username   TEXT,
    ip         TEXT,
    created_at REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_bets_round      ON bets(round_id, status);
CREATE INDEX IF NOT EXISTS idx_bets_user       ON bets(user_id, id);
CREATE INDEX IF NOT EXISTS idx_tx_user         ON transactions(user_id, id);
CREATE INDEX IF NOT EXISTS idx_attempts        ON login_attempts(created_at);
INSERT OR IGNORE INTO treasury (id, balance) VALUES (1, 0);
