"""Espace administrateur : consultation, ajustements justifiés, journal d'audit."""
from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, url_for

from .auth import admin_required
from .db import get_db, immediate
from .game import GameError, treasury_add, user_credit

bp = Blueprint("admin", __name__, url_prefix="/admin")
PER_PAGE = 50


def _page():
    return max(1, request.args.get("page", 1, type=int))


def _parse_signed(raw):
    raw = (raw or "").strip()
    try:
        v = int(raw)
    except ValueError:
        raise GameError("bad_amount", "Montant entier requis (ex. 500 ou -200).")
    if v == 0 or abs(v) > 10 ** 9:
        raise GameError("bad_amount", "Montant non nul et inférieur à 1 000 000 000.")
    return v


def _reason(raw):
    reason = (raw or "").strip()
    if len(reason) < 5 or len(reason) > 300:
        raise GameError("bad_reason", "Justification obligatoire (5 à 300 caractères).")
    return reason


def _audit(conn, action, target, amount, reason, now):
    conn.execute(
        "INSERT INTO audit_log (admin_id, action, target_user_id, amount, reason, ip, created_at) VALUES (?,?,?,?,?,?,?)",
        (g.user["id"], action, target, amount, reason, request.remote_addr, now))


@bp.route("/")
@admin_required
def dashboard():
    c = get_db()
    stats = {
        "treasury": c.execute("SELECT balance FROM treasury WHERE id=1").fetchone()["balance"],
        "players": c.execute("SELECT COUNT(*) n FROM users WHERE role='player'").fetchone()["n"],
        "balances": c.execute("SELECT COALESCE(SUM(balance),0) n FROM users").fetchone()["n"],
        "escrow": c.execute("SELECT COALESCE(SUM(amount),0) n FROM bets WHERE status='active'").fetchone()["n"],
        "rounds": c.execute("SELECT COUNT(*) n FROM rounds WHERE status='crashed'").fetchone()["n"],
    }
    return render_template("admin/dashboard.html", s=stats)


@bp.route("/users")
@admin_required
def users():
    p = _page()
    rows = get_db().execute(
        "SELECT * FROM users ORDER BY id LIMIT ? OFFSET ?", (PER_PAGE, (p - 1) * PER_PAGE)).fetchall()
    return render_template("admin/users.html", users=rows, page=p)


@bp.route("/users/<int:uid>")
@admin_required
def user_detail(uid):
    c = get_db()
    u = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if u is None:
        abort(404, "Compte introuvable.")
    txs = c.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100", (uid,)).fetchall()
    bets = c.execute(
        """SELECT b.*, r.survived_ticks, r.crash_check FROM bets b JOIN rounds r ON r.id=b.round_id
           WHERE b.user_id=? ORDER BY b.id DESC LIMIT 50""", (uid,)).fetchall()
    return render_template("admin/user.html", u=u, txs=txs, bets=bets)


@bp.route("/users/<int:uid>/adjust", methods=["POST"])
@admin_required
def adjust_user(uid):
    c, now = get_db(), current_app.config["CLOCK"]()
    try:
        delta = _parse_signed(request.form.get("amount"))
        reason = _reason(request.form.get("reason"))
        with immediate(c):
            u = c.execute("SELECT id FROM users WHERE id=?", (uid,)).fetchone()
            if u is None:
                raise GameError("not_found", "Compte introuvable.")
            user_credit(c, uid, delta, "admin_adjust", now, admin_id=g.user["id"], note=reason)
            _audit(c, "adjust_user_balance", uid, delta, reason, now)
        flash(f"Solde ajusté de {delta:+d} crédits fictifs.", "ok")
    except GameError as e:
        flash(e.message, "error")
    return redirect(url_for("admin.user_detail", uid=uid))


@bp.route("/users/<int:uid>/active", methods=["POST"])
@admin_required
def toggle_active(uid):
    c, now = get_db(), current_app.config["CLOCK"]()
    try:
        reason = _reason(request.form.get("reason"))
        if uid == g.user["id"]:
            raise GameError("self", "Tu ne peux pas désactiver ton propre compte.")
        with immediate(c):
            u = c.execute("SELECT is_active FROM users WHERE id=?", (uid,)).fetchone()
            if u is None:
                raise GameError("not_found", "Compte introuvable.")
            new = 0 if u["is_active"] else 1
            c.execute("UPDATE users SET is_active=? WHERE id=?", (new, uid))
            _audit(c, "activate_user" if new else "deactivate_user", uid, None, reason, now)
        flash("Statut du compte mis à jour.", "ok")
    except GameError as e:
        flash(e.message, "error")
    return redirect(url_for("admin.user_detail", uid=uid))


@bp.route("/treasury")
@admin_required
def treasury():
    c, p = get_db(), _page()
    bal = c.execute("SELECT balance FROM treasury WHERE id=1").fetchone()["balance"]
    rows = c.execute("SELECT * FROM treasury_ledger ORDER BY id DESC LIMIT ? OFFSET ?",
                     (PER_PAGE, (p - 1) * PER_PAGE)).fetchall()
    return render_template("admin/treasury.html", balance=bal, rows=rows, page=p)


@bp.route("/treasury/adjust", methods=["POST"])
@admin_required
def adjust_treasury():
    c, now = get_db(), current_app.config["CLOCK"]()
    try:
        delta = _parse_signed(request.form.get("amount"))
        reason = _reason(request.form.get("reason"))
        with immediate(c):
            treasury_add(c, "admin_adjust", delta, now, admin_id=g.user["id"], reason=reason)
            _audit(c, "adjust_treasury", None, delta, reason, now)
        flash(f"Caisse ajustée de {delta:+d} crédits fictifs.", "ok")
    except GameError as e:
        flash(e.message, "error")
    return redirect(url_for("admin.treasury"))


@bp.route("/rounds")
@admin_required
def rounds():
    c, p = get_db(), _page()
    rows = c.execute(
        """SELECT r.*, (SELECT COUNT(*) FROM bets b WHERE b.round_id=r.id) AS nbets,
                  (SELECT COALESCE(SUM(amount),0) FROM bets b WHERE b.round_id=r.id) AS staked,
                  (SELECT COALESCE(SUM(payout),0) FROM bets b WHERE b.round_id=r.id AND b.status='cashed') AS paid
           FROM rounds r ORDER BY r.id DESC LIMIT ? OFFSET ?""", (PER_PAGE, (p - 1) * PER_PAGE)).fetchall()
    return render_template("admin/rounds.html", rounds=rows, page=p)


@bp.route("/audit")
@admin_required
def audit():
    c, p = get_db(), _page()
    rows = c.execute(
        """SELECT a.*, u.username AS admin_name, t.username AS target_name FROM audit_log a
           LEFT JOIN users u ON u.id=a.admin_id LEFT JOIN users t ON t.id=a.target_user_id
           ORDER BY a.id DESC LIMIT ? OFFSET ?""", (PER_PAGE, (p - 1) * PER_PAGE)).fetchall()
    return render_template("admin/audit.html", rows=rows, page=p)
