"""Pages de jeu et API JSON (polling HTTP)."""
from flask import Blueprint, current_app, g, jsonify, render_template, request

from .auth import login_required
from .db import get_db
from .game import GameError, cash_out, place_bet, public_state

bp = Blueprint("play", __name__)


def _ctx():
    cfg = current_app.config
    return get_db(), cfg["CLOCK"](), cfg, cfg["CRASH_DRAW"]


@bp.route("/game")
@login_required
def game():
    return render_template("game.html", cfg=current_app.config)


@bp.route("/history")
@login_required
def history():
    conn = get_db()
    page = max(1, request.args.get("page", 1, type=int))
    bets = conn.execute(
        """SELECT b.*, r.crash_check, r.survived_ticks FROM bets b JOIN rounds r ON r.id = b.round_id
           WHERE b.user_id = ? ORDER BY b.id DESC LIMIT 30 OFFSET ?""", (g.user["id"], (page - 1) * 30)).fetchall()
    txs = conn.execute(
        "SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 30", (g.user["id"],)).fetchall()
    return render_template("history.html", bets=bets, txs=txs, page=page)


@bp.route("/api/state")
@login_required
def api_state():
    conn, now, cfg, draw = _ctx()
    return jsonify(public_state(conn, g.user, now, cfg, draw))


def _json_error(e: GameError):
    return jsonify(error=e.code, message=e.message), e.status


@bp.route("/api/bet", methods=["POST"])
@login_required
def api_bet():
    conn, now, cfg, draw = _ctx()
    data = request.get_json(silent=True) or {}
    try:
        res = place_bet(conn, g.user["id"], data.get("amount"), now, cfg, draw)
    except GameError as e:
        return _json_error(e)
    return jsonify(ok=True, **res)


@bp.route("/api/cashout", methods=["POST"])
@login_required
def api_cashout():
    conn, now, cfg, draw = _ctx()
    try:
        res = cash_out(conn, g.user["id"], now, cfg, draw)
    except GameError as e:
        return _json_error(e)
    return jsonify(ok=True, **res)
