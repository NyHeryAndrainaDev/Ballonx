"""Accès SQLite : une connexion par requête, transactions explicites BEGIN IMMEDIATE."""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from flask import current_app, g

_JOURNAL_MODES = {"WAL", "DELETE", "TRUNCATE", "MEMORY"}


def connect(path, journal="WAL"):
    conn = sqlite3.connect(str(path), timeout=10, isolation_level=None)  # autocommit, BEGIN manuel
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 8000")
    journal = journal.upper()
    if journal in _JOURNAL_MODES:
        conn.execute(f"PRAGMA journal_mode = {journal}")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"], current_app.config["JOURNAL_MODE"])
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


@contextmanager
def immediate(conn):
    """Transaction à verrou d'écriture immédiat : sérialise les modifications concurrentes."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def init_schema(conn):
    schema = (Path(__file__).parent / "schema.sql").read_text(encoding="utf-8")
    conn.executescript(schema)
