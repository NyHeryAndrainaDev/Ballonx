// BalloonX — client léger. Il N'EST PAS une autorité : il affiche l'état envoyé par le serveur
// (polling toutes les 500 ms) et envoie des demandes (miser / retirer) que le serveur valide.
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  var el = {
    balance: $('balance'), players: $('players'), phase: $('phase'), mult: $('mult'),
    balloon: $('balloon'), man: $('man'), overlay: $('overlay'), history: $('history'),
    input: $('bet-input'), btn: $('action-btn'), msg: $('msg'), root: $('game-root')
  };
  var POLL_MS = parseInt(el.root.getAttribute('data-poll'), 10) || 500;
  var st = null, busy = false, curRound = null, manStarted = false, vanishTimer = null, noticeUntil = 0;

  function api(path, body) {
    var opts = { method: body === undefined ? 'GET' : 'POST', credentials: 'same-origin',
                 headers: { 'X-CSRF-Token': csrf } };
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    return fetch(path, opts).then(function (r) {
      if (r.status === 401) { window.location.href = '/login'; throw new Error('auth'); }
      return r.json().then(function (j) { j.__status = r.status; return j; });
    });
  }
  function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
  function say(text, cls, ms) { el.msg.textContent = text; el.msg.className = 'msg ' + (cls || ''); noticeUntil = Date.now() + (ms || 0); }

  // ---------- petit homme : animation CSS linéaire, uniquement visuelle ----------
  function resetMan() {
    clearTimeout(vanishTimer);
    el.man.classList.remove('shrinking', 'paused', 'vanished');
    el.man.style.removeProperty('animation-delay');
    void el.man.offsetWidth;            // relance propre de l'animation
    el.balloon.classList.remove('popped');
    manStarted = false;
  }
  function vanish() { el.man.classList.add('vanished'); }
  function startMan(s) {
    var shrink = s.shrink_seconds, elapsed = s.flight_elapsed || 0;
    el.man.style.setProperty('--shrink', shrink + 's');
    el.man.style.animationDelay = '-' + elapsed + 's';   // synchronise avec le temps de vol serveur
    el.man.classList.add('shrinking');
    manStarted = true;
    if (elapsed >= shrink) { vanish(); return; }
    if (s.phase === 'flying') vanishTimer = setTimeout(vanish, (shrink - elapsed) * 1000);
  }
  el.man.addEventListener('animationend', vanish);

  // ---------- rendu ----------
  function render(s) {
    st = s;
    if (s.round_id !== curRound) { curRound = s.round_id; resetMan(); }
    if ((s.phase === 'flying' || s.phase === 'crashed') && !manStarted) startMan(s);
    if (s.phase === 'crashed') { el.man.classList.add('paused'); el.balloon.classList.add('popped'); clearTimeout(vanishTimer); }

    if (el.msg.textContent.indexOf('Connexion perdue') === 0) say('', '', 0);
    el.mult.textContent = s.multiplier + '×';
    el.mult.className = 'mult' + (s.phase === 'crashed' ? ' crashed' : '');
    el.players.textContent = s.bets_count + ' mise(s) · ' + fmt(s.bets_total) + ' cr';
    el.balance.textContent = fmt(s.me.balance);

    var bet = s.me.bet;
    if (s.phase === 'betting') el.phase.textContent = 'Mises ouvertes — départ dans ' + Math.ceil(s.betting_remaining) + ' s';
    else if (s.phase === 'flying') el.phase.textContent = 'Vol en cours';
    else el.phase.textContent = 'Crash — prochaine partie dans ' + Math.ceil(s.next_round_in) + ' s';

    el.overlay.hidden = s.phase !== 'crashed';
    if (s.phase === 'crashed') {
      var t = 'CRASH à ' + s.crash_multiplier + '×', cls = 'overlay bad';
      if (bet && bet.status === 'lost') t += ' — mise perdue (−' + fmt(bet.amount) + ')';
      if (bet && bet.status === 'cashed') { t += ' — retiré à ' + bet.multiplier + '× (+' + fmt(bet.net) + ')'; cls = 'overlay good'; }
      el.overlay.textContent = t; el.overlay.className = cls;
    }
    renderButton(s, bet);
    renderHistory(s.history);
  }

  function renderButton(s, bet) {
    var b = el.btn; b.className = 'btn big'; b.dataset.mode = '';
    if (s.phase === 'betting' && !bet) {
      b.classList.add('green'); b.textContent = 'MISE'; b.dataset.mode = 'bet'; b.disabled = busy;
    } else if (s.phase === 'betting' && bet) {
      b.textContent = 'Mise acceptée : ' + fmt(bet.amount); b.disabled = true;
    } else if (s.phase === 'flying' && bet && bet.status === 'active') {
      b.classList.add('yellow'); b.dataset.mode = 'cashout'; b.disabled = busy;
      b.textContent = 'RETIRER ' + fmt(bet.potential_gross) + ' (' + (bet.potential_net >= 0 ? '+' : '') + fmt(bet.potential_net) + ')';
    } else if (bet && bet.status === 'cashed') {
      b.textContent = 'Retiré : +' + fmt(bet.net); b.disabled = true;
    } else if (s.phase === 'crashed') {
      b.textContent = bet && bet.status === 'lost' ? 'Perdu' : 'Crash'; b.disabled = true;
    } else {
      b.textContent = 'Attends le prochain tour'; b.disabled = true;
    }
  }

  function renderHistory(h) {
    var f = document.createDocumentFragment();
    h.forEach(function (m) { var sp = document.createElement('span'); sp.textContent = m + '×'; if (parseFloat(m) >= 2) sp.className = 'hi'; f.appendChild(sp); });
    el.history.replaceChildren(f);
  }

  // ---------- actions (le serveur décide) ----------
  el.btn.addEventListener('click', function () {
    var mode = el.btn.dataset.mode;
    if (busy || !mode) return;
    busy = true; el.btn.disabled = true;
    var p;
    if (mode === 'bet') {
      var amount = parseInt(el.input.value, 10);
      if (!(amount >= 1)) { busy = false; say('Entre une mise valide.', 'err', 2500); return; }
      p = api('/api/bet', { amount: amount });
    } else p = api('/api/cashout', {});
    p.then(function (r) {
      if (r.ok) {
        if (mode === 'cashout') say('Retiré à ' + r.multiplier + '× : +' + fmt(r.payout) + ' cr (net ' + (r.net >= 0 ? '+' : '') + fmt(r.net) + ')', 'ok', 4000);
        else say('Mise de ' + fmt(r.amount) + ' acceptée.', 'ok', 2500);
      } else say(r.message || 'Action refusée.', 'err', 3500);
    }).catch(function () { say('Erreur réseau.', 'err', 2500); })
      .then(function () { busy = false; poll(true); });
  });

  document.querySelectorAll('.chip').forEach(function (c) {
    c.addEventListener('click', function () {
      var v = parseInt(el.input.value, 10) || 1, a = c.dataset.act;
      if (a === 'half') v = Math.max(1, Math.floor(v / 2));
      if (a === 'double') v = v * 2;
      if (a === 'max' && st) v = Math.max(1, st.me.balance);
      el.input.value = String(v);
    });
  });
  el.input.addEventListener('input', function () { el.input.value = el.input.value.replace(/\D/g, '').slice(0, 9); });

  // ---------- polling HTTP toutes les 500 ms (1,5 s si l'onglet est caché) ----------
  var timer = null, inflight = false;
  function poll(now) {
    clearTimeout(timer);
    if (inflight) return schedule();
    inflight = true;
    api('/api/state').then(render).catch(function () {
      if (Date.now() > noticeUntil) say('Connexion perdue… nouvelle tentative.', 'err', 0);
    }).then(function () { inflight = false; schedule(); });
  }
  function schedule() { timer = setTimeout(poll, document.hidden ? 1500 : POLL_MS); }
  poll();
})();
