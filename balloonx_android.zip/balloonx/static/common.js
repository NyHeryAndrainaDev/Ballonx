// Icônes Lucide : utilisées seulement si vendor/lucide.min.js est présent (sinon rien ne change).
document.addEventListener('DOMContentLoaded', function () {
  if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons();
});
